const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-3538e376.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "css": [
      "entry.27253da5.css"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
